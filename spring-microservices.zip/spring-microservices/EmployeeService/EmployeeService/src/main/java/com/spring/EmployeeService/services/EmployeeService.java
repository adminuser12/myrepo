package com.spring.EmployeeService.services;

import com.spring.EmployeeService.model.Employee;

import java.util.List;

public interface EmployeeService {

    public Employee saveEmployee(Employee employee);

    Employee getEmployeeById(long empid);
}
