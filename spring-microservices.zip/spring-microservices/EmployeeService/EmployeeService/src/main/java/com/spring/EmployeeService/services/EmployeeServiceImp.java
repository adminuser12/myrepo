package com.spring.EmployeeService.services;

import com.spring.EmployeeService.model.Employee;
import com.spring.EmployeeService.repository.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImp implements EmployeeService{

    @Autowired
    private EmployeeRepo employeeRepo;

    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeRepo.save(employee);
    }

    @Override
    public Employee getEmployeeById(long empid) {
        Employee employee = employeeRepo.findById((int) empid).get();

        return employee;
    }
}
