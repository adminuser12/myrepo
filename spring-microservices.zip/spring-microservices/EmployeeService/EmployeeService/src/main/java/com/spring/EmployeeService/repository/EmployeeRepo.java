package com.spring.EmployeeService.repository;

import com.spring.EmployeeService.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

}
