package com.spring.DepartmentService.repository;

import com.spring.DepartmentService.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepo extends JpaRepository<Department, Integer> {
}
