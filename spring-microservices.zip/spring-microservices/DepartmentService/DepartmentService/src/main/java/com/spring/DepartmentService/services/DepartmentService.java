package com.spring.DepartmentService.services;

import com.spring.DepartmentService.model.Department;


public interface DepartmentService {

    public Department saveDepartment(Department department);

    Department getDepartmentByCode(long deptcode);
}
