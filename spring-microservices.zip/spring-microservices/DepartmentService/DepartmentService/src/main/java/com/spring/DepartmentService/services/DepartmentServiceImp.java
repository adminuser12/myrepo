package com.spring.DepartmentService.services;

import com.spring.DepartmentService.model.Department;
import com.spring.DepartmentService.repository.DepartmentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepartmentServiceImp implements DepartmentService {

    @Autowired
    private DepartmentRepo departmentRepo;


    @Override
    public Department saveDepartment(Department department) {

        Department dept = departmentRepo.save(department);
        return dept;
    }

    @Override
    public Department getDepartmentByCode(long deptcode) {
        Department department = departmentRepo.findById((int) deptcode).get();
        return department;
    }
}
