package com.spring.DepartmentService.controller;

import com.spring.DepartmentService.model.Department;
import com.spring.DepartmentService.services.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/controller")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @PostMapping("/addDepartment")
    public ResponseEntity<Department> saveDepartment(@RequestBody Department department){
       Department dept = departmentService.saveDepartment(department);
        return new ResponseEntity<>(dept, HttpStatus.CREATED);
    }

    @GetMapping("/fecthDepartment/{deptcode}")
    public ResponseEntity<Department> getDepartmentByCode(@PathVariable long deptcode ){
       Department department  = departmentService.getDepartmentByCode(deptcode);
        return new ResponseEntity<>(department, HttpStatus.OK);
    }
}
